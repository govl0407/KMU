let x = 10;
let sum = x + y;
let y = 20;
console.log(sum);