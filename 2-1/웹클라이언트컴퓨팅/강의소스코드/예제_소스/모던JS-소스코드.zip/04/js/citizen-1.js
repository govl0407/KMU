let sum = (a, b) => a + b;
sum(2, 10);

// function add(a, b) {
//   return a + b;
// }

// let sum = add;
// sum(2, 10);