window.addEventListener("contextmenu", e => {
  e.preventDefault();
  alert("오른쪽 버튼을 사용할 수 없습니다.")
});