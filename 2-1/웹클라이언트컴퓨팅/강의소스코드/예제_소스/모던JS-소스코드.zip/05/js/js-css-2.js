const userName = document.querySelector("#desc p");

userName.onclick = () => {
  userName.style.color = "red";
}