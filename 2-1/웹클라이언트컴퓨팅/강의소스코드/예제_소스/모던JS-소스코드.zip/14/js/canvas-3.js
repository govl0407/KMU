const canvas = document.querySelector('canvas');
const ctx = canvas.getContext("2d");    

ctx.fillStyle = "rgb(200,0,0)";
ctx.fillRect(10, 10, 50, 100);