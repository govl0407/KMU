const canvas = document.querySelector('canvas');
const ctx = canvas.getContext("2d");

ctx.fillStyle = "yellow";
ctx.strokeStyle = "red";

ctx.font = "italic 60px serif";
ctx.fillText("Javascript", 50, 70);
ctx.strokeText("Javascript", 50, 70);
ctx.font = "bold 60px sans-serif";
ctx.fillText("Javascript", 50, 150);
ctx.strokeText("Javascript", 50, 150);