function displayHello() {
  console.log("Hello");
}

displayHello();