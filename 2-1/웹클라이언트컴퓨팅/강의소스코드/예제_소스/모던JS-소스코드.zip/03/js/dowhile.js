let stars = parseInt(prompt("별의 갯수 : "));

do {
  document.write('*');
  stars--;
} while (stars > 0)